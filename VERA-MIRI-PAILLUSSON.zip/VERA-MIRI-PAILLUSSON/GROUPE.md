# GROUPE VERA-MIRI-PAILLUSSON

Composé de : 

VERA Nicolas - GR3 TpF
MIRI Seyed Amineddin - GR3 TpE
PAILLUSSON Mattéo - GR3 TpE

